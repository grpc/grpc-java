Protocol buffer definitions for the Dubbo proxy.
