Protocol buffer definitions for the ZooKeeper proxy.
